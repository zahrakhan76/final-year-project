// Placeholder for API-related functions or configurations
export const fetchData = async () => {
    return {
        chartData: [10, 20, 30],
        tableData: [
            { id: 1, name: 'Item 1', value: 100 },
            { id: 2, name: 'Item 2', value: 200 }
        ]
    };
};